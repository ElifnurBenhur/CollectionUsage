public class VectorFunctions {
}
