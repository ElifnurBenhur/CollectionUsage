public class StackFunctions {
}
